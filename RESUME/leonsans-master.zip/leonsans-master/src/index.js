const LeonSans = require('./leonsans').default;
module.exports = LeonSans;